package Myi18n;
use base 'Locale::Maketext';
use Locale::Maketext::Lexicon { 'en'    => [ Gettext => 'en.po' ],
                                _style => 'gettext',
};

1
